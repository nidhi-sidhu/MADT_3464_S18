/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task1;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Bowler extends Player
{
    int overThrown;
    int runsGiven;
    int wicketsTaken;
    int runsPerOver;
    int runsPerWicket;
    int bowlingPoints;
    int runPerOver;
    int runPerWicket;
   
    
    Scanner sc1=new Scanner(System.in);

    public Bowler() 
    {
        super();
        this.overThrown=0;
        this.runsPerWicket=0;
        this.wicketsTaken=0;
        this.runsPerOver=0;
        this.runsGiven=0;
        this.bowlingPoints=0;
    }

    public Bowler(String PlayerID,String PlayerName,int overThrown, int runsGiven, int wicketsTaken,int runsPerOver,int runsPerWicket, int bowlingPoints)
    {
        super(PlayerID,PlayerName);
        this.overThrown = overThrown;
        this.runsGiven = runsGiven;
        this.wicketsTaken = wicketsTaken;
        this.runsPerOver = runsPerOver;
        this.runsPerWicket = runsPerWicket;
        this.bowlingPoints = bowlingPoints;
    }
    
    public void setOverThrown() {
        this.overThrown = overThrown;
        System.out.println("Enter OverThrown Points: ");
        this.overThrown=sc1.nextInt();
    }
    
  
    public int getOverThrown()
    {
        return overThrown;
    }
    
    public void setRunsGiven() 
    {
        System.out.println("Enter the runsGiven:");
        this.runsGiven = sc1.nextInt();
        
    }
    
    public int getRunsGiven() 
    {
        return runsGiven;
    }
    
    public void setWicketsTaken()
    {
        System.out.println("Enter wicketTaken");
        this.wicketsTaken = sc1.nextInt();
    }
    
    public String readData()
    {
       String personaldetails = super.readData();
        setOverThrown();
        setRunsGiven();
        setWicketsTaken();
        return personaldetails+overThrown+runsGiven+wicketsTaken;
       
    }
    
    public String toString()
    {
        String data="Player type is : Batsman" + " \n Overthrown points are : " +overThrown+
                "\n Runs Given by this player are : " + runsGiven + " \n Wickets Taken by his :"
                +wicketsTaken+ "\n Runs taken by per over are : " +runPerOver+ " \n Runs taken by per wicket are : " 
                + runPerWicket+ " \n Bowling points are : "+bowlingPoints;
        
        
        return data;
    }
    
    public void calAvg()
    {
        try{
        runPerOver=(runsGiven/overThrown);  
        
        runPerWicket=(runsGiven/wicketsTaken);
        }
        catch(Exception e)
        {
            
        }
     
    }
    
    public void calPoints()
    {
        
    }

    
    
    
    
    
    
}
