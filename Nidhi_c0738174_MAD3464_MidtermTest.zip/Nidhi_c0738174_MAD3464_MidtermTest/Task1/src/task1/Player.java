/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task1;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Player 
{
    String PlayerID;
    String PlayerName;
    
    Scanner sc=new Scanner(System.in);
    
    public Player()
    {
        PlayerID="P###";
        PlayerName="unknown";
    }

    public Player(String PlayerID, String PlayerName)
    {
        this.PlayerID = PlayerID;
        this.PlayerName = PlayerName;
    }
    
    

    public void setPlayerID() 
    {
        this.PlayerID = PlayerID;
        System.out.println("Enter PlayerId : ");
        this.PlayerID=sc.nextLine();
    }
    
    public String getPlayerID() 
    {
        return PlayerID;
    }

    public void setPlayerName()
    {
        this.PlayerName = PlayerName;
        System.out.println("Enter Player Name : ");
        this.PlayerName=sc.nextLine();
    }

    public String readData()
    {
        setPlayerID();
        setPlayerName();
        return PlayerID+PlayerName;
    }
    
    @Override
    public String toString()
    {
       String data="\n PlayerID is : " + PlayerID + " \n Name of the player is :  " + PlayerName ;
       return data;
    }
    
    
    
    
}
