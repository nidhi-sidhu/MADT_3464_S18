/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task1;

/**
 *
 * @author macstudent
 */
public class Batsman extends Player
{
    int BowlsPlayed;
    int runsTaken;
    float strikeRate;
    int totalRuns;
    float batingPoints;

    public Batsman()
    {
      super();
      this.BowlsPlayed=0;
      this.runsTaken=0;
      this.strikeRate=0.00f;
      this.totalRuns=0;
      this.batingPoints=0;
    }

    public Batsman(int BowlsPlayed, int runsTaken, float strikeRate, int totalRuns, float batingPoints) 
    {
        this.BowlsPlayed = BowlsPlayed;
        this.runsTaken = runsTaken;
        this.strikeRate = strikeRate;
        this.totalRuns = totalRuns;
        this.batingPoints = batingPoints;
    }
    
    
     
    
    
    
    
}
