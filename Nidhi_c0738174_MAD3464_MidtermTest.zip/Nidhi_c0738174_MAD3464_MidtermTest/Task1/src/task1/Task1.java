/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task1;

/**
 *
 * @author macstudent
 */
public class Task1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Player p1=new Player();
        //System.out.println("PlayerId : " + p1.PlayerID + " \n PlayerName : " + p1.PlayerName);
        //System.out.println(p1.readData());
        //p1.readData();
        //System.out.println(p1.toString());
        
        Bowler b1=new Bowler();
        b1.readData();
        Bowler b2=new Bowler();
        b2.calAvg();
        System.out.println(b1.toString());
        System.out.println(b2.toString());
        
    }
    
}
