/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task2;

/**
 *
 * @author macstudent
 */
class Encrypt{

    String Encryption1(String n)
    {
    
         String s = "";
    
        for (int i=0;i<n.length();i++)
        {
        
            if(i%2 == 0){
                
            char ch = n.charAt(i);
            if(ch>=90){
            ch = 64;
            }
            char temp = Character.toUpperCase((char) (ch+2));
        
            s = s+temp;
            }else{
            
                 char ch = n.charAt(i);
            
            char temp = Character.toUpperCase((char) (ch+1));
        
            s = s+temp;
            
            }
            
        }
        
    
    return s;
    }
   
     String Encryption2(String n)
     {
         
          String s = "";
         
          String temp1 = "";
           String temp2 = "";
          
          
           for (int i=0;i<n.length();i++){
           
                if(i%2 == 0){
                 char ch = n.charAt(i);
                 
                 temp1 = temp1+ch;
                 
                
                }else{
                char ch = n.charAt(i);
                 
                 temp2 = temp2+ch;
                
                }
               
           
           
           }
         
     s = temp2+temp1;
           
     return s;
     }

}
