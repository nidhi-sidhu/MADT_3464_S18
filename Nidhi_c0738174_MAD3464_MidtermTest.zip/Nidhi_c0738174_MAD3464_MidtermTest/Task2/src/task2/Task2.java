/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task2;

/**
 *
 * @author macstudent
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

 class Task2 extends Encrypt
 {
    public static boolean testAllUpperCase(String str)
    {
		for(int i=0; i<str.length(); i++)
                {
			char c = str.charAt(i);
			if(c >= 97 && c <= 122) 
                        {
				return false;
			}
		}
		
		return true;
	}
    
    
   public static void main(String args[]) throws IOException 
    {
       BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));     
        System.out.print("Enter your name: ");
 
           String name = reader.readLine();                 
           
           if(Task2.testAllUpperCase(name))
           {                 
           
               if(name.length()==5)
               {                     
               
                   Encrypt obj = new Encrypt();
                   
                  String n1 = obj.Encryption1(name);
                  String n2 = obj.Encryption2(name);
                  
                  System.out.println(n1+n2);
                   
               }
               else{
                   System.out.println("Enter valid input");
               
                   main(null);    
                   
               }   
           }
           else{
               System.out.println("Enter valid input");
           
             main(null);      
               
           }
    }
    
}

